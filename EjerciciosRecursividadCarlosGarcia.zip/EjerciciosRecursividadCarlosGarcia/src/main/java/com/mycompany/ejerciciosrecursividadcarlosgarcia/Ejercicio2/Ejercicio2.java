/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejerciciosrecursividadcarlosgarcia.Ejercicio2;

/**
 *
 * @author cegf1
 */
public class Ejercicio2 {
    
    class Nodo {
        String dato;
        Nodo siguiente;

        public Nodo(String dato) {
            this.dato = dato;
            this.siguiente = this; 
        }
    }

    class ListaCircular {
        Nodo cabeza;
        Nodo cola;

        public ListaCircular() {
            cabeza = null;
            cola = null;
        }

        public void insertar(String dato) {
            Nodo nuevoNodo = new Nodo(dato);
            if (cabeza == null) {
                cabeza = nuevoNodo;
                cola = nuevoNodo;
            } else {
                cola.siguiente = nuevoNodo; 
                nuevoNodo.siguiente = cabeza; 
                cola = nuevoNodo; 
            }
        }

        public String concatenarPalabras() {
            if (cabeza != null) {
                Nodo temp = cabeza;
                StringBuilder palabrasConcatenadas = new StringBuilder();
                do {
                    palabrasConcatenadas.append(temp.dato);
                    temp = temp.siguiente;
                } while (temp != cabeza);
                return palabrasConcatenadas.toString();
            } else {
                return "La lista está vacía";
            }
        }
    }
    
    public static void main(String[] args) {
        Ejercicio2 ejercicio = new Ejercicio2();
        ListaCircular lista = ejercicio.new ListaCircular();


        String[] palabras = {"Plaza", "monoplaza", "biplaza", "multiplaza"};


        for (String palabra : palabras) {
            lista.insertar(palabra);
        }

        
        String resultado = lista.concatenarPalabras();
        System.out.println(resultado);
    }
}
