/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejerciciosrecursividadcarlosgarcia.Ejercicio1;

/**
 *
 * @author cegf1
 */
public class Ejercicio1 {
    
    public class SumaRecursiva {
    public static void main(String[] args) {
        int[] arreglo = {1, 2, 3, 4, 5};
        int resultado = SumarArregloRecursivo(arreglo, arreglo.length - 1);
        System.out.println(resultado);
    }

    public static int SumarArregloRecursivo(int[] arreglo, int indice) {
    
        if (indice < 0) {
            return 0;
        }
        
        return arreglo[indice] + SumarArregloRecursivo(arreglo, indice - 1);
    }
    }
}
