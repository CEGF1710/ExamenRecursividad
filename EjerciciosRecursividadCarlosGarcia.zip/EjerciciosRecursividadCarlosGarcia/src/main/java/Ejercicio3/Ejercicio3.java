/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicio3;

/**
 *
 * @author cegf1
 */
public class Ejercicio3 {

     private Stack<String> pila = new Stack<>();

    public void llenarPila() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese elementos a la pila. Escriba 'fin' para terminar:");
        String elemento = scanner.nextLine();
        while (!elemento.equalsIgnoreCase("fin")) {
            pila.push(elemento);
            elemento = scanner.nextLine();
        }
    }

    public void imprimirYVaciarPila() {
        if (!pila.isEmpty()) {
            System.out.println(pila.pop());
            imprimirYVaciarPila();
        }
    }

    public static void main(String[] args) {
        PilaInversa pilaInversa = new PilaInversa();
        pilaInversa.llenarPila();
        System.out.println("Elementos de la pila en orden inverso:");
        pilaInversa.imprimirYVaciarPila();
    }
}