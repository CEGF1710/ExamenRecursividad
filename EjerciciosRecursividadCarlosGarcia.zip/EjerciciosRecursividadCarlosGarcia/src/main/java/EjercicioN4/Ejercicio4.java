/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjercicioN4;

/**
 *
 * @author cegf1
 */
import java.util.Scanner;

public class Ejercicio4 {
    

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        
        System.out.println("Ingrese el primer número para calcular su factorial:");
        int numeroA = scanner.nextInt();
        int factorialA = calcularFactorial(numeroA);
        System.out.println("El factorial de " + numeroA + " es: " + factorialA);
        

        System.out.println("Ingrese el segundo número para elevarlo a una potencia:");
        int base = scanner.nextInt();
        

        System.out.println("Ingrese el tercer número que será la potencia:");
        int potencia = scanner.nextInt();
        int resultadoPotencia = calcularPotencia(base, potencia);
        System.out.println(base + " elevado a la " + potencia + " es: " + resultadoPotencia);
        

        int sumaResultados = factorialA + resultadoPotencia;
        System.out.println("La suma del factorial de " + numeroA + " y " + base + " elevado a la " + potencia + " es: " + sumaResultados);
        
        scanner.close();
    }
    

    public static int calcularFactorial(int numero) {
        if (numero == 0) return 1;
        int factorial = 1;
        for (int i = 1; i <= numero; i++) {
            factorial *= i;
        }
        return factorial;
    }
    
    public static int calcularPotencia(int base, int exponente) {
        int resultado = 1;
        for (int i = 0; i < exponente; i++) {
            resultado *= base;
        }
        return resultado;
    }
}


  
